import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

function main() {
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({ antialias: true, canvas });

    const fov = 75;
    const aspect = 2;
    const near = 0.1;
    const far = 10;
    const camera = new THREE.PerspectiveCamera(fov, aspect, near, far);
    camera.position.z = 4;

    const scene = new THREE.Scene();

    const loader = new THREE.TextureLoader();
    loader.load('./img/waves.jpg', function(texture) {
        scene.background = texture;
    });

    // Lumière
    const light = new THREE.DirectionalLight(0xFFFFFF, 3);
    light.position.set(2, 10, 1);
    scene.add(light);

    // Géométrie des cubes
    let boxWidth = 1;
    const boxHeight = 1;
    const boxDepth = 1;
    let geometry = new THREE.BoxGeometry(boxWidth, boxHeight, boxDepth);

    // Création des cubes
    const material = new THREE.MeshStandardMaterial({ color: 0x00ff00 });
    const cube = new THREE.Mesh(geometry, material);
    scene.add(cube);

    // Contrôles d'orbite
    const controls = new OrbitControls(camera, canvas);
    controls.target.set(0, 0, 0);
    controls.minDistance = 2;
    controls.maxDistance = 10;
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;

    // Mise à jour de la géométrie des cubes
    function updateCubeGeometry(newWidth) {
        geometry.dispose(); // Libérer l'ancienne géométrie de la mémoire
        geometry = new THREE.BoxGeometry(newWidth, boxHeight, boxDepth);
        cube.geometry = geometry; // Mettre à jour la géométrie du cube
    }

    // Écouteur d'événements pour la largeur des cubes
    const wChange = document.querySelector("#wChange");
    wChange.addEventListener('input', function() {
        const newWidth = parseFloat(wChange.value);
        if (!isNaN(newWidth) && newWidth > 0) {
            updateCubeGeometry(newWidth);
        }
    });

    // Fonctions de rendu
    function resizeRendererToDisplaySize(renderer) {
        const canvas = renderer.domElement;
        const width = canvas.clientWidth;
        const height = canvas.clientHeight;
        const needResize = canvas.width !== width || canvas.height !== height;
        if (needResize) {
            renderer.setSize(width, height, false);
        }
        return needResize;
    }

    function render() {
        if (resizeRendererToDisplaySize(renderer)) {
            camera.aspect = canvas.clientWidth / canvas.clientHeight;
            camera.updateProjectionMatrix();
        }
        renderer.render(scene, camera);
        requestAnimationFrame(render);
    }

    requestAnimationFrame(render);
}

main();
